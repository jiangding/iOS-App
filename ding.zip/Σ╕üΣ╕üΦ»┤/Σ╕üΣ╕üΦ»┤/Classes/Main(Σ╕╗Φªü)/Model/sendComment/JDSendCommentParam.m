//
//  JDSendCommentParam.m
//  丁丁说
//
//  Created by JiangDing on 15/12/13.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDSendCommentParam.h"

@implementation JDSendCommentParam

@end
