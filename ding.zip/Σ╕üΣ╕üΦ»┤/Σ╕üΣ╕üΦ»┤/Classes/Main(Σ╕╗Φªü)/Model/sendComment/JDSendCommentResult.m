//
//  JDSendCommentResult.m
//  丁丁说
//
//  Created by JiangDing on 15/12/13.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDSendCommentResult.h"

@implementation JDSendCommentResult

@end
