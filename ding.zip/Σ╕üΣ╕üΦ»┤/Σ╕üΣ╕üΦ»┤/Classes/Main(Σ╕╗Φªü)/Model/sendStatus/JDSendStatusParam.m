//
//  JDSendStatusParam.m
//  丁丁说
//
//  Created by JiangDing on 15/11/29.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDSendStatusParam.h"

@implementation JDSendStatusParam

@end
