//
//  JDHomeStatusParam.m
//  丁丁说
//
//  Created by JiangDing on 15/11/26.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDHomeStatusParam.h"

@implementation JDHomeStatusParam

- (NSNumber *)count
{
    return  (_count != nil) ? _count : @20;
}

@end
