//
//  JDStatusReportParam.m
//  丁丁说
//
//  Created by JiangDing on 15/12/12.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDStatusReportParam.h"

@implementation JDStatusReportParam

@end
