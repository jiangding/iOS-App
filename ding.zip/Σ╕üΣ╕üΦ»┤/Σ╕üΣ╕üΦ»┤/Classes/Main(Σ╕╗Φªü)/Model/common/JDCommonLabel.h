//
//  JDCommonLabel.h
//  丁丁说
//
//  Created by JiangDing on 15/12/7.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDCommonItem.h"

@interface JDCommonLabel : JDCommonItem

/** 右边label显示的内容 */
@property (nonatomic, copy) NSString *text;

@end
