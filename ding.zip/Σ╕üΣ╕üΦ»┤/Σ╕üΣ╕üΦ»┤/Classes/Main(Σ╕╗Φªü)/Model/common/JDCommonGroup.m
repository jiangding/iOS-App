//
//  JDCommonGroup.m
//  丁丁说
//
//  Created by JiangDing on 15/12/7.
//  Copyright © 2015年 JiangDing. All rights reserved.
//  组

#import "JDCommonGroup.h"

@implementation JDCommonGroup

+(instancetype)group
{
    return [[self alloc] init];
}

@end
