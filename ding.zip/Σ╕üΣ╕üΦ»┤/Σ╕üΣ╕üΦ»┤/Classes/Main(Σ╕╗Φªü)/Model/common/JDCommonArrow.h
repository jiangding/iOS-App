//
//  JDCommonArrow.h
//  丁丁说
//
//  Created by JiangDing on 15/12/7.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDCommonItem.h"

@interface JDCommonArrow : JDCommonItem

@end
