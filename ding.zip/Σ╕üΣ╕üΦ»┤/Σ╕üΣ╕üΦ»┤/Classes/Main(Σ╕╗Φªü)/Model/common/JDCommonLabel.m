//
//  JDCommonLabel.m
//  丁丁说
//
//  Created by JiangDing on 15/12/7.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import "JDCommonLabel.h"

@implementation JDCommonLabel

@end
