//
//  JDCommonTableController.h
//  丁丁说
//
//  Created by JiangDing on 15/12/7.
//  Copyright © 2015年 JiangDing. All rights reserved.
//  公用的tableViewController

#import <UIKit/UIKit.h>

@interface JDCommonController : UITableViewController


/** 存储数据 */
@property (nonatomic, strong) NSMutableArray *groups;

@end
