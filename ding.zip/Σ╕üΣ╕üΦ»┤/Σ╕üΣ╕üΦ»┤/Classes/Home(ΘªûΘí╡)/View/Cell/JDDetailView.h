//
//  JDDetailView.h
//  丁丁说
//
//  Created by JiangDing on 15/11/29.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JDDetaiFrame;

@interface JDDetailView : UIImageView

/** frame数据 */
@property (nonatomic, strong) JDDetaiFrame *detaiFrame;

@end
