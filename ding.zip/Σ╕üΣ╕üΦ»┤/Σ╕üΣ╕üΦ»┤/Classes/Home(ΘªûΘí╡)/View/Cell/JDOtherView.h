//
//  JDOtherView.h
//  丁丁说
//
//  Created by JiangDing on 15/11/29.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JDOtherFrame;

@interface JDOtherView : UIImageView

@property (nonatomic, strong) JDOtherFrame *otherFrame;
@end
