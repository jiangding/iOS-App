//
//  JDPhotoView.h
//  丁丁说
//
//  Created by JiangDing on 15/11/30.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JDPhoto;

@interface JDPhotoView : UIImageView

/** 图片mod */
@property (nonatomic, strong) JDPhoto *photoMod;


@end
