//
//  JDDetailTableCover.h
//  丁丁说
//
//  Created by JiangDing on 15/12/11.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDDetailTableCover : UIView

/**
 *  label的文字
 */
@property (nonatomic, strong) NSString *text;
@end
