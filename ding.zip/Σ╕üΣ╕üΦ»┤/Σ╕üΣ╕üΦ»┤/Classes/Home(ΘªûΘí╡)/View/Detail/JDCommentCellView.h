//
//  JDCommentCellView.h
//  丁丁说
//
//  Created by JiangDing on 15/12/10.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JDCommentFrame;

@interface JDCommentCellView : UIView

/** 模型数据 */
@property (nonatomic, strong) JDCommentFrame *commentFrame;
 

@end
