//
//  JDTitleView.h
//  丁丁说
//
//  Created by JiangDing on 15/12/13.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    JDHomeTitleTypeDefault = 1,
    JDHomeTitleType1,
    JDHomeTitleType2,
    JDHomeTitleType3,
    JDHomeTitleType4,
    JDHomeTitleType5
} JDHomeTitleType;


@interface JDTitleView : UIScrollView
 
@end
