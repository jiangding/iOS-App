//
//  JDCar.h
//  丁丁说
//
//  Created by JiangDing on 15/12/15.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JDCar : NSObject
/** 图片  */
@property (nonatomic, copy) NSString *icon;
/** 名字 */
@property (nonatomic, copy) NSString *name;
@end
