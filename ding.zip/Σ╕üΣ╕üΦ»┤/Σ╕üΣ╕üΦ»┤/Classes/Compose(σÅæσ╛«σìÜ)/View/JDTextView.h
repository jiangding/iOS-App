//
//  JDTextView.h
//  丁丁说
//
//  Created by JiangDing on 15/11/24.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface JDTextView : UITextView

/** 占位文字 */
@property (nonatomic, copy) NSString *placeholder;
 
@end
