//
//  JDEmotionGridView.h
//  丁丁说
//
//  Created by JiangDing on 15/12/3.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDEmotionGridView : UIView

/** 每页emotion */
@property (nonatomic, strong) NSArray *emotions;

@end
