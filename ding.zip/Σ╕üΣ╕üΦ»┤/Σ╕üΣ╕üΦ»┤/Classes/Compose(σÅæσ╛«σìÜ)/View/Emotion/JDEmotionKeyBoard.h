//
//  JDEmotionKeyBoard.h
//  丁丁说
//
//  Created by JiangDing on 15/12/3.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDEmotionKeyBoard : UIView

/** 初始化类方法 */
+ (instancetype)keybaord;

@end
