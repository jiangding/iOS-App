//
//  JDEmotionScrollView.h
//  丁丁说
//
//  Created by JiangDing on 15/12/3.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JDEmotionScrollView : UIView

/**
 *  所有的emotion
 */
@property (nonatomic, strong) NSArray *emotions;

@end
