//
//  JDEmotionBtn.h
//  丁丁说
//
//  Created by JiangDing on 15/12/3.
//  Copyright © 2015年 JiangDing. All rights reserved.
//

#import <UIKit/UIKit.h>
@class JDEmotion;

@interface JDEmotionBtn : UIButton

/** emotion模型 */
@property (nonatomic, strong) JDEmotion *emotion;

@end
